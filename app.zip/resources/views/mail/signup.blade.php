<!DOCTYPE html>
<html>
<head>

	<title>Mail</title>
</head>
<body>

 <h2>{{ $title }}</h2>
<pre> {{ $Mail }}</pre>
 <pre> {{ $Password }} </pre>
 <pre>{{ $Massage }}</pre>
</body>
</html>