<?php

namespace App\model\admin;

use Illuminate\Database\Eloquent\Model;

class Facts extends Model
{
    protected $fillable = [ 'name', 'facts' ];
}
