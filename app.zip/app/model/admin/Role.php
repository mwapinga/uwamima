<?php

namespace App\model\admin;

use Laratrust\LaratrustRole;

class Role extends LaratrustRole
{
  
}
