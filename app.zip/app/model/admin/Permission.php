<?php
namespace App\model\admin;

use Laratrust\LaratrustPermission;

class Permission extends LaratrustPermission
{
    
}
