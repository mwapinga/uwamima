<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
<div class="middle-box text-center loginscreen">
  <div class="widgets-container">
   <a href="<?php echo e(URL::to('permission/' . $user->id . '/edit')); ?>" class="btn btn-block btn-info"><i class="glyphicon glyphicon-edit" aria-hidden="true"></i> ADD ROLE TO THE USER</a>  
   <br><br><br>

    <h3>EDIT PERMISSION FOR</h3>
    <p><?php echo e($user->name); ?> USER</p>
    <p>Existing Roles:: 
     
      <?php $__currentLoopData = $user->Role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><i class="alert-danger"><?php echo e($element->name); ?></i></p>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </p>
           <?php echo Form::open(['method'=>'POST','route'=> 'permit.detach']); ?> 

      <div class="form-group">
                <p>Remove Role</p>
                <div class="col-sm-14">
                  <select id="role_id" name="role_id" class="form-control bottom15<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>">

                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($roles->id); ?>" > <?php echo e($roles->name); ?> :: <?php echo e($roles->display_name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
                </div>        
           </div>
           <?php echo Form::hidden('id', $user->id, []); ?>

         <div class="form-group">
            <p>Enter your Password To Confirm Updates</p>
            <input id="password" placeholder="*Password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"  name="password" required>  
            <?php if($errors->has('password')): ?>
            <div class="alert alert-danger" >     
                     <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($errors->first('password')); ?></strong>
                     </span>
            </div>         
             <?php endif; ?>

             <?php if(\Session::has('success')): ?>
            <div class="alert alert-danger">
          <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
            <?php endif; ?>

      </div>

      <div class="form-group">
       <?php echo Form::submit('REMOVE ROLE', ['class'=>'btn btn-primary' ,'onclick'=>'return confirm(\'are you sure you want to make this changes?\');']); ?>

     </div>
     <?php echo Form::close(); ?>

  </div>
</div>
 --}}
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>