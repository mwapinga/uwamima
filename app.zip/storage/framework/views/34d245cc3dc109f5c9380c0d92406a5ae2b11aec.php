<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">


<!-- end col-3 -->

		<div class="col-lg-3">
<!-- Start feed -->
<div class="ibox float-e-margins">
	<div class="ibox-title">
		<h5>Message</h5>
	</div>
	<div class="ibox-content collapse in" id="demo6">
		<div class="widgets-container ">
			<div class="feed-activity-list">

				<?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="feed-element">
					<a href="<?php echo e(URL::to('uwadmin/'.$text->id )); ?>" class="pull-left"> <img alt="image" class="img-circle" src="<?php echo e(asset('assets/images/user.jpg')); ?>"> </a>
					<div class="media-body "> <small class="pull-right text-navy"><?php echo e($text->created_at->diffForHumans()); ?></small> <estrong><?php echo e($text->name?$text->name:'Anonymous'); ?> <br> <strong> <?php echo e($text->email); ?></strong>.
						<br>
						<small class="text-muted"></strong><?php echo e($text->subject?$text->subject:'No subject'); ?></small>
						<br>
						<small class="text-muted"></strong><?php echo e(str_limit($text->message,90)); ?></small>
						<div class="actions"> 
							<a href="<?php echo e(URL::to('uwadmin/'.$text->id )); ?>" class="btn btn-xs btn-white"> View </a>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</div>
<!-- End feed -->



        </div>
      </div>

      <br><br ><br><Br><Br><br>
        <?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>