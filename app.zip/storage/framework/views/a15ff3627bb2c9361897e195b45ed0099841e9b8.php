<?php $__env->startSection('content'); ?>

                                      <?php if(\Session::has('success')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('success')); ?></p>
                                      </div><br />
                                       <?php endif; ?>
     <div class="sb2-2-3">

            <div class="btn admin-upload-btn">
                    <a href="<?php echo e(url('slide/create')); ?>"><span>Add Slider</span></a>
                    </div>
                       <br /> <br />
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Home Page Slider <span class="label label-danger">Not more than 5 Currently slide will be Displayed To the Website </span></h4>
                                </div>
                                <div class="tab-inn">
                                    <div class="table-responsive table-desi">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Slider image</th>
													<th>Img URL</th>
                                                    <th>tag 1</th>
													<th>tag 2</th>
													<th>Status</th>
													<th>Edit</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            	<?php if($slider): ?>

                                            	<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index+1); ?></td>
                            <td><span class="list-img"><img src="<?php echo e(asset('asset/images/'.$slide->photo->photo_tag)); ?>" alt=""></span></td>
                            <td><?php echo e($slide->photo->photo_tag); ?> </td>
                            <td><?php echo e($slide->tags1?$slide->tags1:'No tags..!!'); ?></td>
							<td><?php echo e($slide->tags2?$slide->tags2:'No tags..!!'); ?></td>
                            <td>
                                <?php if($slide->status): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-danger">Not Active</span>
                                <?php endif; ?>
                            </td>
							<td><a href="<?php echo e(URL::to('slide/' . $slide->id . '/edit')); ?>"class="ad-st-view">Edit</a></td>
                        </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>