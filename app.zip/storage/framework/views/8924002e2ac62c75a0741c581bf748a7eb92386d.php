<?php $__env->startSection('content'); ?>
  <!--== User Details ==-->
                <div class="sb2-2-3">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp admin-form">
                                <div class="inn-title">
                                    <h4>Add Portfolio</h4>
                                </div>
                                <div class="tab-inn">
                                     <?php echo $__env->make('includes.Errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo Form::open(['method'=>'POST','route'=> 'portfolio.store','files'=>true]); ?>



           <div class="row" >
               <div class="input-field col s12">
                        <?php echo Form::label('name', 'Enter Photo Tag  (max characters 25)'); ?>

                        <?php echo Form::text('name', null, ['class'=>'validate','required' ]); ?>

               </div>

            </div>
                  <div class="row">
                      <div class="file-field input-field col s12">
                          <div class="btn admin-upload-btn">
                              <span>File</span>
                <?php echo Form::file('photo_id', ['class'=>'required', 'multiple']); ?>

                          </div>
                  <div class="file-path-wrapper">
                      <input class="file-path validate" type="text" placeholder="Slider image">
                  </div>
                      </div>
                  </div>
                                            <div class="row">
                                    <div class="input-field col s12">
                                    <?php echo Form::label('status', 'Status:'); ?>


                                    <?php echo Form::select('status', [1=>'active',0=>'Not active'],0); ?>


                                    </div>
                                    </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <i class="waves-effect waves-light btn-large waves-input-wrapper" style=""><input type="submit" class="waves-button-input" value="Submit"></i>
                                            </div>
                                        </div>
                                   <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>