<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
<div class="middle-box text-center loginscreen">
  <div class="widgets-container">
    
    <a href="<?php echo e(URL::to('/det/'.$user->id)); ?>" class="btn btn-block btn-info"><i class="glyphicon glyphicon-edit" aria-hidden="true"></i> REMOVE ROLE USER</a>  
   <br><br><br>
    <h3>EDIT PERMISSION FOR <?php echo e($user->name); ?> USER</h3>
    <p>Existing Roles:: 
     
      <?php $__currentLoopData = $user->Role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><i class="alert-danger"><?php echo e($element->name); ?></i></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </p>

     <?php echo Form::model($user, ['method'=>'PATCH','route'=> ['permission.update' , $user->id ]]); ?>

            
             <?php echo Form::hidden('id', $user->id); ?>

      <div class="form-group">
                <p>ADD Role</p>
                <div class="col-sm-14">
                  <select id="role_id" name="role_id" class="form-control bottom15<?php echo e($errors->has('role_id') ? ' is-invalid' : ''); ?>">

                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($roles->id); ?>" > <?php echo e($roles->name); ?> :: <?php echo e($roles->display_name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
                </div>        
                <?php if($errors->has('role_id')): ?>
                <div class="alert alert-danger" >
                      <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('role_id')); ?></strong>
                      </span>
                </div>           
                <?php endif; ?> 
  
           </div>
           <div class="form-group">
                <p>Edit Status</p>
                <div class="col-sm-14">
                  <select id="status" name="status" class="form-control bottom15<?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>">    
                    <option value="0" >Not Active </option>
                    <option value="1"> Active </option>  
                  </select>
                </div>        
                <?php if($errors->has('status')): ?>
                <div class="alert alert-danger" >
                      <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('status')); ?></strong>
                      </span>
                </div>           
                <?php endif; ?> 
  
           </div>
      
         <div class="form-group">
            <p>Enter your Password To Confirm Updates</p>
            <input id="password" placeholder="*Password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"  name="password" required>  
            <?php if($errors->has('password')): ?>
            <div class="alert alert-danger" >     
                     <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($errors->first('password')); ?></strong>
                     </span>
            </div>         
             <?php endif; ?>

             <?php if(\Session::has('success')): ?>
            <div class="alert alert-danger">
          <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
            <?php endif; ?>

      </div>

      <div class="form-group">
       <?php echo Form::submit('EDIT PERMISSION', ['class'=>'btn btn-primary' ,'onclick'=>'return confirm(\'are you sure you want to make this changes?\');']); ?>

     </div>
     <?php echo Form::close(); ?>


      <?php if($user->id != Auth::user()->id): ?>

     <a href="<?php echo e(URL::to('permission/'.$user->id )); ?>" class="btn btn-block btn-danger"><i class="glyphicon glyphicon-delete" aria-hidden="true"></i> DELETE USER</a>     
      <?php endif; ?>
  </div>
</div>


</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>