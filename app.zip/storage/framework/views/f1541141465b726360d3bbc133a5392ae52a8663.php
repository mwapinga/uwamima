<?php $__env->startSection('content'); ?>

<!-- page title -->
<section class="page-title">
    <div class="container">
        <div class="content-box">
            <div class="title">Blog <span>News</span></div>
            <div class="bread-crumb">
                <a href="<?php echo e(url('/')); ?>">Home &nbsp;</a> /&nbsp;<span>Blog News</span>
            </div>
        </div>
    </div>
</section>
<!--End Page Title-->


<!-- blog classic -->
<section class="blog-details news-section blog-page">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 col-xs-12 content-side">
                <div class="blog-details-content">
                    <div class="content-style-one">
                        <div class="single-item">
                            <div class="img-box">
                                <figure><img src="<?php echo e(asset('asset/images/'.$blg->photo->photo_tag)); ?>" alt=""></figure>
                            </div>
                            <div class="lower-content">
                                <div class="meta">UWAMIMA</div>
                                <h4><?php echo e($blg->header); ?></h4>
                                <div class="quote centred">
                                    <div class="text">
                                        <?php echo e($blg->Body); ?>

                                    </div>
                                    <h5>-By

                                            <?php $__currentLoopData = $blg->user->Role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($roles->name); ?>

                                            <?php break; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </h5>
                                </div>

                            </div>
                        </div>
                        <div class="post-share-option">
                            <ul class="tag-post">
                                <li class="tag"><?php echo e($blg->created_at->diffForHumans()); ?></li>
                            </ul>
                            <div class="addthis_inline_share_toolbox"></div>
                        </div>
                    </div>
                    <div class="comment-area">
                        <div class="comment-title">COMMENTS(<?php echo e(count($blg->comments)); ?>)</div>

                       <?php $__currentLoopData = $blg->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($comm->status == 1): ?>

                        <div class="single-comment">
                            <div class="comment-img"><figure><img src="<?php echo e(asset('asset/images/user.jpg')); ?>" alt=""></figure></div>
                            <div class="title"><?php echo e($comm->name?$comm->name:'Anonymous'); ?></div>
                            <div class="time">
                                <div class="text"><?php echo e($comm->created_at->diffForHumans()); ?></div>
                            </div>
                            <div class="text">
                                <p><?php echo e($comm->comment); ?></p>
                            </div>
                        </div>
                        
                             <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
     <div class="comment-form">
                        <div class="comment-title">POST A COMMENT</div>
                        <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                         <p><?php echo e(\Session::get('success')); ?></p>
                         </div><br />
                          <?php endif; ?>
                        <?php echo Form::open(['method'=>'POST','route'=> 'blg.store']); ?>

                            <div class="row">

                            <?php echo Form::hidden('blog_id', $blg->id); ?>


                             <div class="col-md-6 col-sm-6 col-xs-12">
                                            <?php echo Form::label('name'); ?>

                                            <?php echo Form::text('name', null, ['class'=>'validate','placeholder'=>'Your Name' ]); ?>

                                            <?php if($errors->has('name')): ?>
                                            <div class="alert alert-danger" >
                                             <span class="invalid-feedback" role="alert">
                                                 <strong><?php echo e($errors->first('name')); ?></strong>
                                             </span>
                                            </div>
                                         <?php endif; ?>
                             </div>
                             <div class="col-md-6 col-sm-6 col-xs-12">
                                    <?php echo Form::label('email'); ?>

                                    <?php echo Form::email('email', null, ['class'=>'validate','placeholder'=>'Your Email' ]); ?>

                                    <?php if($errors->has('email')): ?>
                                    <div class="alert alert-danger" >
                                     <span class="invalid-feedback" role="alert">
                                         <strong><?php echo e($errors->first('email')); ?></strong>
                                     </span>
                                    </div>
                                 <?php endif; ?>
                              </div>

                              <div class="col-md-12 col-sm-12 col-xs-12">
                                    <?php echo Form::label('comment'); ?>

                                    <?php echo Form::textarea('comment', null, ['class'=>'validate','required','placeholder'=>'Your comment']); ?>

                                    <?php if($errors->has('comment')): ?>
                                <div class="alert alert-danger" >
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($errors->first('comment')); ?></strong>
                                 </span>
                                </div>
                             <?php endif; ?>

                           </div>
                            </div>
                            <button type="submit" class="btn-one" data-loading-text="Please wait..."> COMMENT</button>
                        </form>
                    </div>
                </div>
 </div>
            <div class="col-md-3 col-sm-6 col-xs-12 sidebar-side">
                <div class="sidebar">
                    <div class="sidebar-search sidebar-wideget">
                        <div class="sidebar-title"><h4>Search</h4></div>
                        <div class="search-box">
                            <form action="#">
                                <input type="text" placeholder="Search...">
                                <button><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="sidebar-post sidebar-wideget">
                        <div class="sidebar-title"><h4>Recent Post</h4></div>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sinlge-post">
                            <div class="img-box"><a href="<?php echo e(url('/blg/'.$new->id)); ?>"><figure><img src="<?php echo e(asset('asset/images/'.$new->photo->photo_tag)); ?>" alt=""></figure></a></div>
                            <div class="post-title"><a href="<?php echo e(url('/blg/'.$new->id)); ?>"><?php echo e($new->header); ?></a></div>
                            <div class="text"><?php echo e($new->created_at->diffForHumans()); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- blog classic end -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>