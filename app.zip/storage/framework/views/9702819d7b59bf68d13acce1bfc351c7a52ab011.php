<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
          <li class="active"> <strong> Second Import  Form </strong> </li>
        </ol>
      </div>
    </div>
          <div class="col-lg-6 top20">
          <div class="widgets-container">
            <h5>Fill the form Below</h5>

     <?php echo Form::open(['method'=>'POST','route'=> 'uwadminimport.store']); ?>  
         <div class="form-group">
                <?php echo Form::label('name', 'Owner Name:'); ?>

                <?php echo Form::text('name', null , ['class'=>'form-control']); ?>

             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
          <div class="form-group">
                <?php echo Form::label('farmname', 'Farmer Name:'); ?>

                <?php echo Form::text('farmname', null , ['class'=>'form-control']); ?>

             <?php if($errors->has('farmname')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('farmname')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
                   <div class="form-group">
                <?php echo Form::label('date', 'Date:'); ?>

                <?php echo Form::date('date', null, ['class'=>'form-control']); ?>

            
            <?php if($errors->has('date')): ?>
              <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('date')); ?></strong>
                </span>
                </div>
            <?php endif; ?>
          

         </div>

         <div class="form-group">
                <?php echo Form::label('drivername', 'Driver Name:'); ?>

                <?php echo Form::text('drivername', null, ['class'=>'form-control', 'placeholder'=>'Fist and Second Name']); ?>


                           
            <?php if($errors->has('drivername')): ?>
                 <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('drivername')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>
         
         </div> 

         <div class="form-group">
                <?php echo Form::label('carnumber', 'Car Number:'); ?>

                <?php echo Form::text('carnumber', null, ['class'=>'form-control']); ?>

                      
            <?php if($errors->has('carnumber')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('carnumber')); ?></strong>
                </span>
                </div>
            <?php endif; ?> 
         </div> 
 
          <div class="form-group">
                <?php echo Form::label('intime', 'In Time:'); ?>

                <?php echo Form::time('intime', null, ['class'=>'form-control']); ?>


                           
            <?php if($errors->has('intime')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('intime')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>
         
         </div>

          <div class="form-group">
                <?php echo Form::label('outime', 'Out Time:'); ?>

                <?php echo Form::time('outime', null, ['class'=>'form-control']); ?>


        
                           
            <?php if($errors->has('outime')): ?>
                 <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('outime')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>         
         </div>
         <div class="form-group">
           <?php echo Form::submit('SUBMIT IMPORT', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>