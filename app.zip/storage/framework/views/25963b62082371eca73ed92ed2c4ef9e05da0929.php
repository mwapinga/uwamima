<?php $__env->startSection('content'); ?>


     <div class="sb2-2-3">
                   <?php if(\Session::has('success')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('success')); ?></p>
                                      </div><br />
                  <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Manage Comments </h4>

                                </div>
                                <div class="tab-inn">
                                    <div class="table-responsive table-desi">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Post</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Comments</th>
                                                    <th>Status</th>
                                                
													
                                                </tr>
                                            </thead>
                                            <tbody>

                        	<?php if($comm): ?>
                        	<?php $__currentLoopData = $comm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $staf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index+1); ?></td>
                    <td>
                    <?php 
                    $post = \App\model\admin\blog::where('id',$staf->blog_id)->get()->first();
                    ?>
                     <?php echo e(str_limit($post->header,24)); ?>

                    </td>
					<td><?php echo e($staf->name?$staf->name:'Anonymous'); ?></td>
                    <td><?php echo e($staf->email?$staf->email:'No email'); ?></td>
					<td><?php echo e($staf->comment); ?></td>
                    <td>
                         <?php if($staf->status): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-danger">Not ctive</span>
                                <?php endif; ?>
                            </td>
                    <?php if(!$staf->status): ?>
                    <td>
                        <div class="btn admin-upload-btn">
                    <a href="<?php echo e(url('commentz/' . $staf->id . '/edit')); ?>"><span>Enable </span></a>
                    </div>
                     </td>
                     <?php endif; ?>
                     <td>
            <?php echo Form::open(['method'=>'DELETE','route'=> ['commentz.destroy',$staf->id]]); ?>  
          <?php echo Form::submit('Delete', ['class'=>'btn red btn', 'onclick'=>'return confirm(\'are you sure you want to delete this comment?\');']); ?>

               <?php echo Form::close(); ?>

                     </td>

                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>