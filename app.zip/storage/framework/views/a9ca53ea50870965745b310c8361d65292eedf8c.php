<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-12">
        <h2> ADD SALES </h2>
        <ol class="breadcrumb">
          <li class="active"> <strong>Sales  Form </strong> </li>
        </ol>
      </div>
    </div>

          <div class="col-lg-6 top20">
          <div class="widgets-container">
            <h5>Fill the form Below</h5>
     <?php echo Form::open(['method'=>'POST','route'=> 'uwadminsale.store']); ?>

        
         <div class="form-group">
                <?php echo Form::label('name', 'Seller Name:'); ?>

                <?php echo Form::text('name', null , ['class'=>'form-control','required']); ?>

             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>      

        <div class="form-group">
                <?php echo Form::label('date', 'Date:'); ?>

                <?php echo Form::date('date', null, ['class'=>'form-control', 'required']); ?>

            
            <?php if($errors->has('date')): ?>
              <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('date')); ?></strong>
                </span>
                </div>
            <?php endif; ?>
          

         </div>

         <div class="form-group">
                <?php echo Form::label('sold_to', 'Buyer:'); ?>

                <?php echo Form::text('sold_to', null, ['class'=>'form-control', 'required']); ?>



                      
            <?php if($errors->has('sold_to')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('sold_to')); ?></strong>
                </span>
                </div>
            <?php endif; ?> 

             <?php if(\Session::has('error')): ?>
                  <div class="alert alert-danger">
                  <p><?php echo e(\Session::get('error')); ?></p>
                    </div><br />
             <?php endif; ?>
         </div> 
         <div class="form-group">
           <?php echo Form::submit('SUBMIT SALES', ['class'=>'btn btn-primary']); ?>

         </div>

         <?php echo Form::close(); ?>

          </div>
        </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>