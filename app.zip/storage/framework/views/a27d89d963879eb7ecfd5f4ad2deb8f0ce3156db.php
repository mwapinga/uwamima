<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">

<?php if($temp): ?>
    <div class="wrapper-content ">
        <div class="row">
      <div class="col-lg-20">
        <div class="ibox float-e-margins">
          <div class="ibox-title">
            <h5> Added Goods Details </h5>
          </div>
          <!-- / ibox-title -->
          <div id="demo2" class="ibox-content collapse in">
            <div class="borderedTable">
              <div class="table-scrollable">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th> # </th>
                      <th> Product </th>
                      <th> Category </th>
                      <th> Size </th>
                      <th> Quantinty </th>

                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tempos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                      <td> <?php echo e($key+1); ?></td>
                      <td> <?php echo e(ucfirst($tempos->product->name)); ?> </td>
                      <td> <?php echo e($tempos->category_id ? ucfirst($tempos->category->name) : 'No category'); ?> </td>
                       <td> <?php echo e($tempos->size_id ? ucfirst($tempos->size->size) : 'No Size'); ?> </td>
                      <td> <?php echo e($tempos->quantity); ?></td>
                       <td>
                            <?php echo Form::open(['method'=>'DELETE','route'=> ['addmore.destroy',$tempos->id]]); ?>

                            <?php echo Form::submit('REMOVE', ['class'=>'btn  btn-danger']); ?>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <a href="<?php echo e(url('uwadminimport/create')); ?>" class="btn btn-block btn-success" ><i class="glyphicon glyphicon-add" aria-hidden="true"></i> NEXT STEP </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>


            <div class="col-lg-12 top20">
               <ol class="breadcrumb">
            <li class="active"> <strong>Add Imports Goods Details </strong> </li><br>
            <label class="alert-danger">Select None for Non available data </label>
              </ol>
            <div class="widgets-container">

    <?php echo Form::open(['method'=>'POST','route'=> 'addmore.store']); ?>

           <div class="form-group col-xs-12 col-sm-3">
                <label>Product Name</label>
                <select id="product_id" name="product_id" class="form-control required bottom15<?php echo e($errors->has('product_id') ? ' is-invalid' : ''); ?>">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prods->id); ?>" > <?php echo e($prods->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

                <?php if($errors->has('product_id')): ?>
                <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('product_id')); ?></strong>
                    </span>
                      </div>
                <?php endif; ?>

             </div>

             <div class="form-group col-xs-12 col-sm-3">
             <label>Category Name</label>
             <select id="category_id" name="category_id" class="form-control", required>
                   <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cats->id); ?>" > <?php echo e($cats->name); ?> </option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
                <?php if($errors->has('category_id')): ?>
                      <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                    </span>
                   </div>
                <?php endif; ?>
                <?php if(\Session::has('successcat')): ?>
                      <div class="alert alert-danger">
                      <p><?php echo e(\Session::get('successcat')); ?></p>
                        </div><br />
                 <?php endif; ?>

             </div>
                <div class="form-group col-xs-12 col-sm-3">
             <label>Size Value</label>
             <select id="size_id" name="size_id" class="form-control", required>
                   <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sizes->id); ?>" > <?php echo e($sizes->size); ?> </option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
                <?php if($errors->has('size_id')): ?>
                      <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('size_id')); ?></strong>
                    </span>
                   </div>
                <?php endif; ?>
                <?php if(\Session::has('success')): ?>
                      <div class="alert alert-danger">
                      <p><?php echo e(\Session::get('success')); ?></p>
                        </div><br />
                 <?php endif; ?>

             </div>



              <div class="form-group col-xs-12 col-sm-3">
                    <?php echo Form::label('quantity', 'Quantity:'); ?>

                    <?php echo Form::number('quantity', null, ['class'=>'form-control', 'required']); ?>


                <?php if($errors->has('quantity')): ?>
                    <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('quantity')); ?></strong>
                    </span>
                    </div>
                <?php endif; ?>
             </div>
             <br>
              <?php echo Form::submit('Add Details', ['class'=>'btn btn-primary']); ?></td>
            <?php echo Form::close(); ?>

     </div>
     </div>


</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>