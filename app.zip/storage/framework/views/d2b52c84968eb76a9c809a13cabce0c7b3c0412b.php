<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-12">
        <h2> EDIT BLOCK </h2>
        <ol class="breadcrumb">
          <li class="active"> <strong>Edit Block  Form </strong> </li>
        </ol>
      </div>
    </div>

          <div class="col-lg-5 top20">
          <div class="widgets-container">
            <h5>Fill the form Below</h5>

         <?php echo Form::model($block, ['method'=>'PATCH','route'=> ['uwablock.update' , $block->id ]]); ?>

             <?php echo Form::hidden('id', $block->id); ?>

         <div class="form-group">
                <?php echo Form::label('name', 'Block Name:'); ?>

                <?php echo Form::text('name', null , ['class'=>'form-control']); ?>

             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
        
            <div class="form-group">
                    <?php echo Form::label('Area', 'Area Meter Square:'); ?>

                    <?php echo Form::number('Area', null, ['class'=>'form-control', 'required']); ?>


                <?php if($errors->has('Area')): ?>
                    <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('Area')); ?></strong>
                    </span>
                    </div>
                <?php endif; ?>
             </div>
             <div class="form-group">
                    <?php echo Form::label('blockFee', 'Block Monthly Fee :'); ?>

                    <?php echo Form::number('blockFee', null, ['class'=>'form-control', 'required']); ?>


                <?php if($errors->has('blockFee')): ?>
                    <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('blockFee')); ?></strong>
                    </span>
                    </div>
                <?php endif; ?>
             </div>



         <div class="form-group">
           <?php echo Form::submit('EDIT BLOCK', ['class'=>'btn btn-primary']); ?>

         </div>

         <button class="btn aqua btn-outline" type="button"><a href="<?php echo e(url('blockowner/'.$block->id.'/edit')); ?>">MANAGE BLOCK OWNER</a></button>
         <?php echo Form::close(); ?>

         <?php echo Form::open(['method'=>'DELETE','route'=> ['uwablock.destroy',$block->id]]); ?>  
        <?php echo Form::submit('DELETE BLOCK', ['class'=>'btn red btn-block', 'onclick'=>'return confirm(\'are you sure you want to delete this block?\');']); ?>

        <?php echo Form::close(); ?>

          </div>
        </div>
  </div>
</div>

 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>