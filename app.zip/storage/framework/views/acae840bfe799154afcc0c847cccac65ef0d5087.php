<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <?php if($success): ?>
   <div class="alert alert-success">
    <p><?php echo e($success); ?> <?php echo e($mail); ?></p>
    </div><br />
   
     <?php else: ?>
      <div class="col-lg-12">
        <button class="btn btn-danger" > <h2>Enter New User Email Adress</h2></button>
      </div>
          <div class="col-lg-12 top20">
          <div class="widgets-container">
          <?php echo Form::open(['method'=>'POST','action'=> 'PermissiontrustController@store']); ?>

        
         <div class="form-group">
                <?php echo Form::label('email', 'New User Email:'); ?>

                <?php echo Form::email('email', null , ['class'=>'form-control','requuired','placeholder'=>'New User Email']); ?>

             <?php if($errors->has('email')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
          </div>
          <div class="form-group">
           <?php echo Form::submit('GRANT ACCES TO NEW USER', ['class'=>'btn btn-danger']); ?>

         </div>
         <?php echo Form::close(); ?>

           </div>
          </div>
        <?php endif; ?>


</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>