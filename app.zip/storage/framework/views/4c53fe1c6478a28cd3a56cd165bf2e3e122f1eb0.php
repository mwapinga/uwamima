<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">


<!-- end col-3 -->

        <div class="col-lg-3">
<!-- Start feed -->
<div class="ibox float-e-margins">
    <div class="ibox-title">
        <h5>Message</h5>
    </div>
    <div class="ibox-content collapse in" id="demo6">
        <div class="widgets-container ">
            <div class="feed-activity-list">
                <div class="feed-element">
                    <a href="#" class="pull-left"> <img alt="image" class="img-circle" src="<?php echo e(asset('assets/images/user.jpg')); ?>"> </a>
                    <div class="media-body "> <small class="pull-right text-navy"><?php echo e($text->created_at->diffForHumans()); ?></small> <strong><?php echo e($text->name?$text->name:'Anonymous'); ?> <br> <strong> <?php echo e($text->email); ?></strong>.
                        <br>
                        <small class="text-muted"></strong><?php echo e($text->subject?$text->subject:'No subject'); ?></small>
                        <br>
                        <small class="text-muted"></strong><?php echo e($text->message); ?></small>

                          <?php echo Form::close(); ?>

         <?php echo Form::open(['method'=>'DELETE','route'=> ['uwadmin.destroy',$text->id]]); ?>  
        <?php echo Form::submit('DELETE', ['class'=>'btn red btn-block', 'onclick'=>'return confirm(\'are you sure you want to delete this message?\');']); ?>

               <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End feed -->



        </div>
      </div>

      <br><br ><br><Br><Br><br>
        <?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>