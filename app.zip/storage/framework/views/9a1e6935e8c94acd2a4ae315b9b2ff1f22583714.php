<?php $__env->startSection('content'); ?>
  <div class="page-content-wrapper animated fadeInRight">
    <div class="page-content" >
      <div class="wrapper-content ">
        <div class="row">
          <div class="col-sm-10">
            <div class="ibox">
              <div class="widgets-container">
                <?php if(\Session::has('success')): ?>
               <div class="alert alert-success">
               <p><?php echo e(\Session::get('success')); ?></p>
               </div><br />
                <?php endif; ?>
                <div class="feed-element"> <a href="#" class="pull-left"> 
                         <?php if(Auth::user()->photo): ?>
                              <img src="<?php echo e(asset('assets/images/'.Auth::user()->photo->photo_tag )); ?>" alt="Photo"> 
                         <?php else: ?> 
                          <img src="<?php echo e(asset('assets/images/user.jpg' )); ?>" alt="No Photo"> 
                         <?php endif; ?>
                   </a>
                  <br><br><br>
                  <div class="media-body "> <h2><strong>Name::   <?php echo e(Auth::user()->name); ?> </strong> ||  User Name:: <?php echo e(Auth::user()->username); ?> <br></h2>
                    <small class="text-muted">Joined <?php echo e(Auth::user()->created_at->diffForHumans()); ?></small>

                    <h4>Status</h4>

                    <div class="actions"> 
                    <?php if(Auth::user()->status): ?>
                     <a class="btn btn-xs aqua"><i class="glyphicon glyphicon-ok"></i> Active</a>
                    <?php else: ?>
                    <a class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove" aria-hidden="true"></i> Not_Active</a>

                    <h4>Be Patient You will Be activated Soon </h4>

                    <?php endif; ?>                      
                    </div>
                  </div>
                </div>             
              </div>
            </div>
            <div class="ibox">
              <div class="widgets-container">
                <h3>Personal Details </h3>
                <table class="table small m-b-xs">
                  <tbody>
                    <tr>
                      <td><h2><strong> <?php echo e(Auth::user()->email); ?> </strong></h2><i>         Email</i> </td>
                      <td><h2><strong><?php echo e(Auth::user()->phone); ?></strong></h2><i>           Phone </i></td>
                    </tr>
                    <tr>
                      <td><h2><strong><?php echo e(Auth::user()->gender == 1 ? 'Male': 'Female'); ?></strong></h2><i>       Gender</i></td>
                      <td><h2><strong><?php echo e(Auth::user()->borndate); ?></strong></h2><i>      Born Date  (yy/dd/mm)</i></td>
                    </tr>
                    <tr>
                      <td><h2><strong> 

                       <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($role->display_name); ?>  <br />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                     </strong></h2><i>         Role </i></td>
                      <td><h2><strong>

                         <?php if(Auth::user()->blocks ): ?>
                         <?php $__currentLoopData = Auth::user()->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php echo e($element->name); ?> ,
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php else: ?>
                         No Block
                         <?php endif; ?>

                 </strong></h2><i>          Block No</i> </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="ibox">
              <div class="widgets-container">
                <?php if(Auth::user()->photo): ?>
                 <H3> Thanks For Using UWAMIMA DASHBOARD TRUST IS THE KEY</H3>
                  <?php else: ?>
                 <div class="form-group">
                <?php echo Form::open(['method'=>'POST','route'=> 'profile.user.edit','files'=>true]); ?>

                <?php echo Form::label('photo_id', 'Add Profile Photo Please:',['class'=>'form-control']); ?> 
                <?php echo Form::file('photo_id', ['class'=>'form-control']); ?>

                <?php echo Form::submit('Add Photo', ['class'=>'btn aqua btn-block']); ?>

                <?php echo Form::close(); ?>

                  <?php endif; ?> 
                 <a href="<?php echo e(URL::to('profedit')); ?>" class="btn btn-block btn-success"><i class="glyphicon glyphicon-edit" aria-hidden="true"></i> EDIT INFO</a>
      
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>