<?php $__env->startSection('content'); ?>


     <div class="sb2-2-3">

                  <div class="btn admin-upload-btn">
                  <a href="<?php echo e(url('portfolio/create')); ?>"><span>Add Portfolio</span></a>
                  </div>
                     <br /> <br />
                   <?php if(\Session::has('success')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('success')); ?></p>
                                      </div><br />
                  <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Home Page Portfolio  <span class="label label-danger">Not more than 15 Currently Photo will be Displayed To the Website </span>  </h4>
                                </div>
                                <div class="inn-title">
                                        <span class="label label-danger">Please use Horizontal Photo </span>
                                    </div>
                                <div class="tab-inn">
                                    <div class="table-responsive table-desi">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Post Images</th>
                                                    <th>Photo Tag</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                        	<?php if($port): ?>
                        	<?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $portf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index+1); ?></td>
                    <td><span class="list-img"><img src="<?php echo e(asset('asset/images/'.$portf->photo->photo_tag)); ?>" alt=""></span></td>
                    <td><?php echo e($portf->name?$portf->name:'No tags..!!'); ?></td>
                    <td>
                         <?php if($portf->status): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-danger">Not ctive</span>
                                <?php endif; ?>
                            </td>
							<td><a href="<?php echo e(URL::to('portfolio/' . $portf->id . '/edit')); ?>"class="ad-st-view">Edit</a></td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>