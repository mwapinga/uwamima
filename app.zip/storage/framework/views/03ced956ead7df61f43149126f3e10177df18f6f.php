<!DOCTYPE html>
<html>
<head>

	<title>Mail</title>
</head>
<body>

 <h2><?php echo e($title); ?></h2>
<pre> <?php echo e($Mail); ?></pre>
 <pre> <?php echo e($Password); ?> </pre>
 <pre><?php echo e($Massage); ?></pre>
</body>
</html>