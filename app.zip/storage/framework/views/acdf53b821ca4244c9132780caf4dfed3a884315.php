<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">

    <div class="wrapper-content ">
        <div class="row">
      <div class="col-lg-20">
        <div class="ibox float-e-margins">
          <div class="ibox-title">
            <h5> Added Type for <?php echo e($prod->name); ?> Product </h5>
          </div>
          <!-- / ibox-title -->
          <div id="demo2" class="ibox-content collapse in">
            <div class="borderedTable">
              <div class="table-scrollable">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <?php if(!count($prod->size)): ?>
                      <th> # </th>
                      <th> Category Name </th>
                      <th> Size Available </th>
                      <?php elseif(count($prod->size)): ?>
                      <th>Size for Products</th>
                      <?php endif; ?>
                      <th> Delete Options </th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php if(!count($prod->size)): ?>
                      <?php $__currentLoopData = $prod->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                      <td> <?php echo e($key+1); ?></td>
                      <td> <?php echo e(ucfirst($cats->name)); ?> </td>
                      
                       <td> 
                          <?php $__currentLoopData = $cats->size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <ul>
                          <li>  <?php echo e($sizes->size); ?> 
                            <?php echo Form::open(['method'=>'DELETE','route'=> ['product.size.delete',$sizes->id]]); ?>

                            <?php echo Form::hidden('category_id', $cats->id, []); ?>

                            <?php echo Form::submit('delete', ['class'=>'btn  btn-danger']); ?>

                            <?php echo Form::close(); ?> </li>
                          </ul>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </td>
                             <?php if($prod->name != $cats->name): ?>
                             <div class="col-lg-1 top20">
                            <?php echo Form::open(['method'=>'POST','route'=> 'product.size.add']); ?>  
                             <div class="form-group">
                                    <?php echo Form::label('size', 'Add Size For '.$cats->name .' Type:'); ?>

                                    <?php echo Form::hidden('product_id',$prod->id , []); ?>

                                    <?php echo Form::hidden('category_id', $cats->id, []); ?>

                                    <?php echo Form::text('size', null , ['class'=>'form-control']); ?>

                                 <?php if($errors->has('size')): ?>
                                   <div class="alert alert-danger" >
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('size')); ?></strong>
                                    </span>
                                   </div>    
                                <?php endif; ?>
                             </div>  
                             <div>
                             <div class="form-group">
                               <?php echo Form::submit('Add Size', ['class'=>'btn btn-primary']); ?>

                             </div>
                             <?php echo Form::close(); ?>

                             <?php endif; ?>
                      
                       <td>
                          <?php if(count($cats->size)): ?>
                          <p> Please Delete All size First</p>
                          <?php else: ?>
                            <?php echo Form::open(['method'=>'DELETE','route'=> ['product.category.delete',$cats->id]]); ?>

                            <?php echo Form::submit('Delete this Type', ['class'=>'btn  btn-danger']); ?>

                            <?php echo Form::close(); ?>

                          <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php elseif(count($prod->size)): ?>
                     <tr>
                           <?php $__currentLoopData = $prod->size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td>  <?php echo e($sizes->size); ?> </td>
                          <td>
                            <?php echo Form::open(['method'=>'DELETE','route'=> ['product.size.delete',$sizes->id]]); ?>

                            <?php echo Form::hidden('product_id', $prod->id, []); ?>

                            <?php echo Form::submit('delete', ['class'=>'btn  btn-danger']); ?>

                            <?php echo Form::close(); ?> </td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                             <div class="col-lg-1 top20">
                            <?php echo Form::open(['method'=>'POST','route'=> 'product.size.add']); ?>  
                             <div class="form-group">
                                    <?php echo Form::label('size', 'Add Size For '.$prod->name .':'); ?>

                                    <?php echo Form::hidden('product_id',$prod->id , []); ?>

                                    <?php echo Form::text('size', null , ['class'=>'form-control']); ?>

                                 <?php if($errors->has('size')): ?>
                                   <div class="alert alert-danger" >
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('size')); ?></strong>
                                    </span>
                                   </div>    
                                <?php endif; ?>
                             </div>  
                             <div>
                             <div class="form-group">
                               <?php echo Form::submit('Add Size', ['class'=>'btn btn-primary']); ?>

                             </div>
                             <?php echo Form::close(); ?>             
                     </tr>
                     <?php endif; ?>
                  </tbody>
                </table>
                <a href="<?php echo e(url('product')); ?>" class="btn btn-block btn-success" ><i class="glyphicon glyphicon-add" aria-hidden="true"></i> DONE </a>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php if(count($prod->category)): ?>
<button class="btn btn-block btn-warning" >DELETE ALL CATEGORY  TO DELETE <?php echo e(strtoupper($prod->name )); ?> PRODUCT </button>
  <?php elseif(count($prod->size)): ?>
<button class="btn btn-block btn-warning" >DELETE ALL  SIZE TO DELETE <?php echo e(strtoupper($prod->name )); ?> PRODUCT </button>
   <?php else: ?>
 <?php echo Form::open(['method'=>'DELETE','route'=> ['product.destroy',$prod->id]]); ?>

 <?php echo Form::submit('Delete Product', ['class'=>'btn  btnblock btn-danger']); ?>

 <?php echo Form::close(); ?>

  <?php endif; ?>

   <?php if(!count($prod->size)): ?>
     <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
          <li class="active"> <strong> Add Type  For  <?php echo e($prod->name); ?>  </strong> </li>
        </ol>
      </div>
    </div>
          <div class="col-lg-3 top20">
          <div class="widgets-container">
     <?php echo Form::open(['method'=>'POST','route'=> 'product.category.add'] ); ?>  
         <div class="form-group">
                <?php echo Form::label('name', 'Type Name:'); ?>

                <?php echo Form::hidden('product_id',$prod->id , []); ?>

                <?php echo Form::text('name', null , ['class'=>'form-control']); ?>


             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
         <div class="form-group">
           <?php echo Form::submit('Add Type', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>
        <?php endif; ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>