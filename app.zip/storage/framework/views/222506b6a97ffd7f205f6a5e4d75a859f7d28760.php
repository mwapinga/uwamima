<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
            <?php if(\Session::has('successp')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('successp')); ?></p>
                                      </div><br />
                  <?php endif; ?>
          <li class="active"> <strong> Add Product </strong> </li>
        </ol>
      </div>
    </div>
          <div class="col-lg-6 top20">
          <div class="widgets-container">

     <?php echo Form::open(['method'=>'POST','route'=> 'product.store']); ?>  
         <div class="form-group ">
                <?php echo Form::label('name', 'Product Name:'); ?>

                <?php echo Form::text('name', null , ['class'=>'form-control']); ?>

             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
         </div>
         <div class="form-group">
           <?php echo Form::submit('ADD PRODUCT', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>
      
        <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
        
        </ol>
      </div>
    </div>
          <div class="col-lg-6 top20">
          <div class="widgets-container">
              <?php if(\Session::has('successcat')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('successcat')); ?></p>
                                      </div><br />
                  <?php endif; ?>
            <label>Add Category For Product</label>
            <hr>
      <?php echo Form::open(['method'=>'POST','route'=> 'product.category.add'] ); ?>  
           <div class="form-group col-xs-12 col-sm-3">
                <label>Select Product</label>                     
                <select id="product_id" name="product_id" class="form-control required bottom15<?php echo e($errors->has('product_id') ? ' is-invalid' : ''); ?>">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prods->id); ?>" > <?php echo e($prods->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

                <?php if($errors->has('product_id')): ?>
                <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('product_id')); ?></strong>
                    </span>
                      </div>
                <?php endif; ?>

             </div>

         <div class="form-group col-xs-12 col-sm-3 ">
                <?php echo Form::label('Catname', 'Type Name:'); ?>

                <?php echo Form::text('Catname', null , ['class'=>'form-control']); ?>


             <?php if($errors->has('Catname')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('Catname')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
         <div class="form-group">
           <?php echo Form::submit('Add Category', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>


            <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
        
        </ol>
      </div>
    </div>
          <div class="col-lg-6 top20">
          <div class="widgets-container">
              <?php if(\Session::has('successsizec')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('successsizec')); ?></p>
                                      </div><br />
                  <?php endif; ?>
            <label>Add Size For Category</label>
            <hr>
      <?php echo Form::open(['method'=>'POST','route'=> 'product.size.add'] ); ?>  
            <div class="form-group col-xs-12 col-sm-3">
             <label>Select Category</label>
             <select id="category_id" name="category_id" class="form-control", required>
                   <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cats->id); ?>" > <?php echo e($cats->name); ?> </option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
                <?php if($errors->has('category_id')): ?>
                      <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                    </span>
                   </div>
                <?php endif; ?>
             </div>

         <div class="form-group col-xs-12 col-sm-3 ">
                <?php echo Form::label('sizename', 'Size Value:'); ?>

                <?php echo Form::text('sizename', null , ['class'=>'form-control']); ?>


             <?php if($errors->has('sizename')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('sizename')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
         <div class="form-group">
           <?php echo Form::submit('Add Size', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>


            <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-6">
        <ol class="breadcrumb">
        
        </ol>
      </div>
    </div>
          <div class="col-lg-6 top20">
          <div class="widgets-container">
              <?php if(\Session::has('successsize')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('successsize')); ?></p>
                                      </div><br />
                  <?php endif; ?>

            <label>Add Size For Product</label>
            <hr>
      <?php echo Form::open(['method'=>'POST','route'=> 'product.size.add'] ); ?>  
           <div class="form-group col-xs-12 col-sm-3">
                <label>Select Product</label>                     
                <select id="product_id" name="product_id" class="form-control required bottom15<?php echo e($errors->has('product_id') ? ' is-invalid' : ''); ?>">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prods->id); ?>" > <?php echo e($prods->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

                <?php if($errors->has('product_id')): ?>
                <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('product_id')); ?></strong>
                    </span>
                      </div>
                <?php endif; ?>

             </div>

         <div class="form-group col-xs-12 col-sm-3 ">
                <?php echo Form::label('sizenameprod', 'Size Value:'); ?>

                <?php echo Form::text('sizenameprod', null , ['class'=>'form-control']); ?>


             <?php if($errors->has('sizenameprod')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('sizenameprod')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>
         <div class="form-group">
           <?php echo Form::submit('Add Size', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

          </div>
        </div>



  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>