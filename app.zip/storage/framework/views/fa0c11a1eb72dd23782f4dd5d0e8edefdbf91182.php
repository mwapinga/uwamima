<?php $__env->startSection('content'); ?>


     <div class="sb2-2-3">

                  <div class="btn admin-upload-btn">
                  <a href="<?php echo e(url('testimonial/create')); ?>"><span>Add Testimonial</span></a>
                  </div>
                     <br /> <br />
                   <?php if(\Session::has('success')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('success')); ?></p>
                                      </div><br />
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4> Home Page Testimonial <span class="label label-danger">Not more than 5 Currently testimonial will be Displayed To the Website </span> </h4>
                                </div>
                                <div class="tab-inn">
                                    <div class="table-responsive table-desi">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Image</th>
                                                    <th>Name</th>
													<th>Tittle</th>
                                                    <th>Testamonial</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>

                        	<?php if($test): ?>
                        	<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index+1); ?></td>
                 <td><span class="list-img"><img src="<?php echo e(asset('asset/images/'.$tests->photo->photo_tag)); ?>" alt=""></span></td>
                    <td><?php echo e($tests->name?$tests->name:'No tags..!!'); ?></td>
					<td><?php echo e($tests->surname?$tests->surname:'No tags..!!'); ?></td>
					<td><?php echo e($tests->Testimonial); ?></td>
                    <td>
                         <?php if($tests->status): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-danger">Not ctive</span>
                                <?php endif; ?>
                            </td>
							<td><a href="<?php echo e(URL::to('testimonial/' . $tests->id . '/edit')); ?>"class="ad-st-view">Edit</a></td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>