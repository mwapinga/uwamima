<?php $__env->startSection('content'); ?>


     <div class="sb2-2-3">
            <div class="btn admin-upload-btn">
                    <a href="<?php echo e(url('blog/create')); ?>"><span>Add Post</span></a>
                    </div>
                       <br /> <br />

                   <?php if(\Session::has('success')): ?>
                   <div class="alert alert-success">
                  <p><?php echo e(\Session::get('success')); ?></p>
                  </div><br />
                  <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Home Page Blog  <span class="label label-danger">Not more than 5 Currently Post will be Displayed To the Website </span>  </h4>

                                </div>
                                <div class="tab-inn">
                                    <div class="table-responsive table-desi">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Post Images</th>
                                                    <th>Header</th>
													<th>Body</th>
                                                    <th>Publisher</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                        	<?php if($bloger): ?>
                        	<?php $__currentLoopData = $bloger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index+1); ?></td>
                    <td><span class="list-img"><img src="<?php echo e(asset('asset/images/'.$blog->photo->photo_tag)); ?>" alt=""></span></td>
                    <td><?php echo e($blog->header?$blog->header:'No tags..!!'); ?></td>
					<td><?php echo e($blog->Body?$blog->Body:'No tags..!!'); ?></td>
					<td><?php echo e($blog->user->name); ?></td>
                    <td>
                         <?php if($blog->status): ?>
                                <span class="label label-success">Active</span>
                                <?php else: ?>
                                <span class="label label-danger">Not ctive</span>
                                <?php endif; ?>
                            </td>
							<td><a href="<?php echo e(URL::to('blog/' . $blog->id . '/edit')); ?>"class="ad-st-view">Edit</a></td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.addmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>