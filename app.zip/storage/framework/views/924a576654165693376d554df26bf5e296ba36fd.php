<?php $__env->startSection('content'); ?>

<!-- page title -->
<section class="page-title">
    <div class="container">
        <div class="content-box">
            <div class="title">Contact <span>Us</span></div>
            <div class="bread-crumb">
                <a href="<?php echo e(url('/')); ?>">Home &nbsp;</a> /&nbsp;<span>Contact Us</span>
            </div>
        </div>
    </div>
</section>
<!--End Page Title-->


<!-- contact info -->
<section class="contact-info centred">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12 contact-column">
                <div class="single-item">
                    <div class="title"><h3>ADDRESS</h3></div>
                    <div class="text">P.o.box 59  <br />Njombe</div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 contact-column">
                <div class="single-item">
                    <div class="title"><h3>Phone Number</h3></div>
                    <div class="text">(+255) 744842713<br />(+255) 716507508 </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 contact-column">
                <div class="single-item hvr-grow-shadow">
                    <div class="title"><h3>Email</h3></div>
                    <div class="text">Uwamima@gmail.com.</div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact info end -->


<!-- contact section -->
<section class="contact-section">
    <div class="container">
        <div class="contact-title centred">Contact form</div>
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12 column">
                <div class="contact-area">
                        <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                         <p><?php echo e(\Session::get('success')); ?></p>
                         </div><br />
                          <?php endif; ?>
                        <?php echo Form::open(['method'=>'POST','route'=> 'contact.store']); ?>

                        <div class="row" >
                           <div class="col-md-6 col-sm-6 col-xs-12">
                                    <?php echo Form::label('name'); ?>

                                    <?php echo Form::text('name', null, ['class'=>'validate','required','placeholder'=>'Your Name' ]); ?>

                                    <?php if($errors->has('name')): ?>
                                    <div class="alert alert-danger" >
                                     <span class="invalid-feedback" role="alert">
                                         <strong><?php echo e($errors->first('name')); ?></strong>
                                     </span>
                                    </div>
                                 <?php endif; ?>
                           </div>
                           <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::label('email'); ?>

                                <?php echo Form::email('email', null, ['class'=>'validate','required','placeholder'=>'Your Email' ]); ?>

                                <?php if($errors->has('email')): ?>
                                <div class="alert alert-danger" >
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($errors->first('email')); ?></strong>
                                 </span>
                                </div>
                             <?php endif; ?>
                          </div>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::label('subject'); ?>

                                <?php echo Form::text('subject', null, ['class'=>'validate','placeholder'=>'Your Subject' ]); ?>

                                <?php if($errors->has('subject')): ?>
                                <div class="alert alert-danger" >
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($errors->first('subject')); ?></strong>
                                 </span>
                                </div>
                             <?php endif; ?>
                          </div>

                           <div class="col-md-12 col-sm-12 col-xs-12">
                                    <?php echo Form::label('message'); ?>

                                    <?php echo Form::textarea('message', null, ['class'=>'validate','required','placeholder'=>'Your Message']); ?>

                                    <?php if($errors->has('message')): ?>
                                <div class="alert alert-danger" >
                                 <span class="invalid-feedback" role="alert">
                                     <strong><?php echo e($errors->first('message')); ?></strong>
                                 </span>
                                </div>
                             <?php endif; ?>

                           </div>
                           <button type="submit" class="btn-one" >SEND YOUR MASSAGE</button>
                        </div>
                     <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12 contact-column">
                <div class="google-map-area">
                    <div
                        class="google-map"
                        id="contact-google-map"
                        data-map-lat="40.086097"
                        data-map-lng="-105.939460"
                        data-icon-path="<?php echo e(asset('asset/images/resources/map-marker.png')); ?>"
                        data-map-title="Brooklyn, New York, United Kingdom"
                        data-map-zoom="12"
                        data-markers='{
                            "marker-1": [40.086097, -105.939460, "<h4>Branch Office</h4><p>77/99 London UK</p>","images/resources/map-marker.png"]
                        }'>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>