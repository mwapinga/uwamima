<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
     <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">


              <div class="ibox-title">
                <h5>Block Owner </h5>
             </div>
             <hr>
            <a href="<?php echo e(URL::to('permission/create')); ?>" class="btn btn-block btn-info"><i class="glyphicon glyphicon-add" aria-hidden="true"></i>ADD NEW BLOCK OWNER </a>
   <hr >
    <?php if(\Session::has('success')): ?>
   <div class="alert alert-success">
    <p><?php echo e(\Session::get('success')); ?></p>
    </div><br />
     <?php endif; ?>
     <div class="ibox-content collapse in">
                <div class="widgets-container">
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
    <thead>
        <tr>
         <th>Id</th>
         <th>Name</th>
         <th>Username</th>
         <th>Block Name</th>
         <th>Email</th>
         <th>Phone</th>
         <th>Gender</th>
         <th>BornDate</th>
         <th>Living Area</th>
         <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php if($user): ?>
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index +1); ?></td>
                <td><?php echo e($users->name); ?> </td>
                <td><?php echo e($users->username?$users->username: "No Username"); ?></td>
                <td>
                 <?php $__currentLoopData = $users->blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($block->name); ?>  <br/>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </td>
                <td><?php echo e($users->email); ?></td>
                <td><?php echo e($users->phone); ?></td>
                <td><?php echo e($users->gender == 1 ? 'Male':'Female'); ?></td>
                <td><?php echo e($users->borndate); ?></td>
                <td><?php echo e($users->adress); ?></td>
                <td>
                 <?php if($users->status): ?>
                     <a class="btn btn-xs aqua"><i class="glyphicon glyphicon-ok"></i> Active</a>
                    <?php else: ?>
                    <a class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove" aria-hidden="true"></i> Not_Active</a>
                    <?php endif; ?> 
                </td> 
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
   </table>
                                    </div>
                               </div>
                         </div>
                     </div>
                  </div>
               </div>
           </div>
         </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>