<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
     <div class="row">
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>AVAILABLE PRODUCT IN THE MARKET</h5>
              </div>
              <BR>
              <button class="btn aqua btn-outline" type="button"><a href="<?php echo e(url('product/create')); ?>"> ADD PRODUCT</a></button>
                   <?php if(\Session::has('succesp')): ?>
                                       <div class="alert alert-success">
                                      <p><?php echo e(\Session::get('succesp')); ?></p>
                                      </div><br />
                   <?php endif; ?>
              <div class="ibox-content collapse in">
               <div>
                 <h1> AVAILABLE PRODUCTS</h1>
                <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <ul>
 <h1><li><?php echo e($index+1); ?> <?php echo e(ucfirst($prods->name)); ?> <button type="button" class="btn blue btn-outline btn-xs"><a href="<?php echo e(URL::to('product/'.$prods->id)); ?>">Edit Product,Category and Size</a> </button></li></h1>        
                 <div >
                    <table id="example7" class="display nowrap table  responsive nowrap table-bordered">
                      <thead>
                       <tr>
                      <?php if(!count($prods->size)): ?>
                       <th>No</th>
                       <th>Category For <?php echo e(ucfirst($prods->name)); ?> </th>  
                       <th>Size Available for Category</th> 
                      <?php elseif(count($prods->size)): ?>
                        <th>Size For Product </th>
                      <?php endif; ?>
                       </tr>
                      </thead>
                    <tbody>

                   <?php if(!count($prods->size)): ?>
                      <?php $__currentLoopData = $prods->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($index+1); ?></td>
                          <td><?php echo e(ucfirst($cat->name)); ?></td>
                          <td>
                         <?php $__currentLoopData = $cat->size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <ul>
                                <li><?php echo e($sizes->size); ?> </li>
                              </ul>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                          </td> 
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif(count($prods->size)): ?> 
                        <td>
                          <?php $__currentLoopData = $prods->size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <ul>
                                <li><?php echo e($sizes->size); ?> </li>
                              </ul>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </td>
                   <?php endif; ?>
                     </tr>
                    </tbody>
                    </table>
                  </div>
                   </ul> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div> 

    <br><br><Br><br><br>
 <?php $__env->stopSection(); ?>
 
  
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>