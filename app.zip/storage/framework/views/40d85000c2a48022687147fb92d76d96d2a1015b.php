<?php $__env->startSection('content'); ?>

<div class="page-content-wrapper animated fadeInRight">
<div class="page-content">
   <div class="row wrapper border-bottom page-heading">
      <div class="col-lg-12">
        <h2> EDIT EXPORT </h2>
        <ol class="breadcrumb">
          <li class="active"> <strong>Edit Export  Form </strong> </li>
        </ol>
      </div>
    </div>

          <div class="col-lg-12 top20">
          <div class="widgets-container">
            <h5>Fill the form Below</h5>

         <?php echo Form::model($exp, ['method'=>'PATCH','route'=> ['uwadminexport.update' , $exp->id ]]); ?>

             <?php echo Form::hidden('id', $exp->id); ?>

         <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('name', 'Owner Name:'); ?>

                <?php echo Form::text('name', $exp->user->name , ['class'=>'form-control']); ?>

             <?php if($errors->has('name')): ?>
               <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
               </div>    
            <?php endif; ?>
        
         </div>

         <div class="form-group col-xs-12 col-sm-3">
            <label>Product Name</label>
            <select id="product_id" name="product_id" class="form-control bottom15<?php echo e($errors->has('product_id') ? ' is-invalid' : ''); ?>">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($prods->id); ?>" > <?php echo e($prods->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>          

            <?php if($errors->has('product_id')): ?>
            <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('product_id')); ?></strong>
                </span>
                  </div>
            <?php endif; ?>
        
         </div>

         <div class="form-group col-xs-12 col-sm-3">
         <label>Category Name</label>
         <select id="category_id" name="category_id" class="form-control">
               <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cats->id); ?>" > <?php echo e($cats->name); ?> </option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select> 
            <?php if($errors->has('category_id')): ?>
                  <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('category_id')); ?></strong>
                </span>
               </div>
            <?php endif; ?>
            <?php if(\Session::has('success')): ?>
                  <div class="alert alert-danger">
                  <p><?php echo e(\Session::get('success')); ?></p>
                    </div><br />
             <?php endif; ?>

         </div> 
              <div class="form-group col-xs-12 col-sm-3">
             <label>Size Value</label>
             <select id="size_id" name="size_id" class="form-control", required>
                   <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sizes->id); ?>" > <?php echo e($sizes->size); ?> </option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
                <?php if($errors->has('size_id')): ?>
                      <div class="alert alert-danger" >
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('size_id')); ?></strong>
                    </span>
                   </div>
                <?php endif; ?>
                <?php if(\Session::has('success')): ?>
                      <div class="alert alert-danger">
                      <p><?php echo e(\Session::get('success')); ?></p>
                        </div><br />
                 <?php endif; ?>

             </div> 

          <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('quantity', 'Quantity:'); ?>

                <?php echo Form::number('quantity', null, ['class'=>'form-control']); ?>


            <?php if($errors->has('quantity')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('quantity')); ?></strong>
                </span>
                </div>
            <?php endif; ?>
         </div> 
                   <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('date', 'Date:'); ?>

                <?php echo Form::date('date', null, ['class'=>'form-control']); ?>

            
            <?php if($errors->has('date')): ?>
              <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('date')); ?></strong>
                </span>
                </div>
            <?php endif; ?>
          

         </div>

         <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('drivername', 'Driver Name:'); ?>

                <?php echo Form::text('drivername', null, ['class'=>'form-control', 'placeholder'=>'Fist and Second Name']); ?>


                           
            <?php if($errors->has('drivername')): ?>
                 <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('drivername')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>
         
         </div> 

         <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('carnumber', 'Car Number:'); ?>

                <?php echo Form::text('carnumber', null, ['class'=>'form-control']); ?>



                      
            <?php if($errors->has('carnumber')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('carnumber')); ?></strong>
                </span>
                </div>
            <?php endif; ?> 
         </div> 
 
          <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('intime', 'In Time:'); ?>

                <?php echo Form::time('intime', null, ['class'=>'form-control']); ?>


                           
            <?php if($errors->has('intime')): ?>
                <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('intime')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>
         
         </div>

          <div class="form-group col-xs-12 col-sm-3">
                <?php echo Form::label('outime', 'Out Time:'); ?>

                <?php echo Form::time('outime', null, ['class'=>'form-control']); ?>


        
                           
            <?php if($errors->has('outime')): ?>
                 <div class="alert alert-danger" >
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('outime')); ?></strong>
                </span>
                 </div>
            <?php endif; ?>         
         </div>
           <BR><br><br>
           <BR><br><br><BR><br><br>
         <div class="form-group">
           <?php echo Form::submit('EDIT IMPORT', ['class'=>'btn btn-primary']); ?>

         </div>
         <?php echo Form::close(); ?>

         <?php echo Form::open(['method'=>'DELETE','route'=> ['uwadminexport.destroy', $exp->id]]); ?>  
        <?php echo Form::submit('DELETE EXPORT', ['class'=>'btn red btn-block', 'onclick'=>'return confirm(\'are you sure you want to delete this import?\');']); ?>

        <?php echo Form::close(); ?>

          </div>
        </div>
  </div>
</div>

 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>